# import pandas as pandas

# df = pd.read_csv("sales-data.csv")

# df_cleaned = df.dropna()

# print(df_cleaned)

print("Hello")
